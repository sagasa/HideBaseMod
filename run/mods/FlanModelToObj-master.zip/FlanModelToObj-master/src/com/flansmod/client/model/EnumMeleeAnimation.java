package com.flansmod.client.model;

public enum EnumMeleeAnimation 
{
	DEFAULT, NONE, BLUNT_SWING, BLUNT_BASH, STAB_UNDERARM, STAB_OVERARM
}
